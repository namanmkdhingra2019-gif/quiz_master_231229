from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.permanent_session_lifetime = timedelta(days=7)  # Make sessions last for 7 days

# Database initialization
def init_db():
    conn = sqlite3.connect('quiz_master.db')
    c = conn.cursor()
    
    # Create users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  full_name TEXT NOT NULL,
                  qualification TEXT NOT NULL,
                  dob DATE NOT NULL)''')
    
    # Create admin user if not exists
    try:
        admin_password = generate_password_hash('admin123')
        c.execute('INSERT INTO users (username, password, full_name, qualification, dob) VALUES (?, ?, ?, ?, ?)',
                 ('admin@quizmaster.com', admin_password, 'Administrator', 'Admin', '2000-01-01'))
    except sqlite3.IntegrityError:
        pass
    
    # Create subjects table
    c.execute('''CREATE TABLE IF NOT EXISTS subjects
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  description TEXT)''')
    
    # Create chapters table
    c.execute('''CREATE TABLE IF NOT EXISTS chapters
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  subject_id INTEGER,
                  name TEXT NOT NULL,
                  description TEXT,
                  FOREIGN KEY (subject_id) REFERENCES subjects (id))''')
    
    # Create quizzes table
    c.execute('''CREATE TABLE IF NOT EXISTS quizzes
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  chapter_id INTEGER,
                  date_of_quiz DATE NOT NULL,
                  time_duration TEXT NOT NULL,
                  remarks TEXT,
                  FOREIGN KEY (chapter_id) REFERENCES chapters (id))''')
    
    # Create questions table
    c.execute('''CREATE TABLE IF NOT EXISTS questions
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  quiz_id INTEGER,
                  question_text TEXT NOT NULL,
                  option_1 TEXT NOT NULL,
                  option_2 TEXT NOT NULL,
                  option_3 TEXT NOT NULL,
                  option_4 TEXT NOT NULL,
                  correct_answer INTEGER NOT NULL,
                  FOREIGN KEY (quiz_id) REFERENCES quizzes (id))''')
    
    # Create scores table
    c.execute('''CREATE TABLE IF NOT EXISTS scores
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  quiz_id INTEGER,
                  user_id INTEGER,
                  time_stamp_of_attempt TIMESTAMP NOT NULL,
                  total_scored INTEGER NOT NULL,
                  FOREIGN KEY (quiz_id) REFERENCES quizzes (id),
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

init_db()

# Helper function to get database connection
def get_db():
    conn = sqlite3.connect('quiz_master.db')
    conn.row_factory = sqlite3.Row
    return conn

# Helper function to check if user is admin
def is_admin():
    return session.get('username') == 'admin@quizmaster.com'

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('user_dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session.permanent = True  # Make the session permanent
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            session['role'] = 'admin' if username == 'admin@quizmaster.com' else 'user'
            
            if session['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('user_dashboard'))
        
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        full_name = request.form['full_name']
        qualification = request.form['qualification']
        dob = request.form['dob']
        
        if username == 'admin@quizmaster.com':
            flash('This username is reserved')
            return redirect(url_for('register'))
        
        conn = get_db()
        try:
            hashed_password = generate_password_hash(password)
            conn.execute('''INSERT INTO users 
                          (username, password, full_name, qualification, dob)
                          VALUES (?, ?, ?, ?, ?)''',
                       (username, hashed_password, full_name, qualification, dob))
            conn.commit()
            flash('Registration successful! Please login.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or session.get('role') != 'admin':
        flash('Please login as administrator', 'error')
        return redirect(url_for('login'))
    
    conn = get_db()
    
    # Get all subjects
    subjects = conn.execute('SELECT * FROM subjects').fetchall()
    
    # Get all chapters with their subject names
    chapters = conn.execute('''
        SELECT ch.*, s.name as subject_name 
        FROM chapters ch
        LEFT JOIN subjects s ON ch.subject_id = s.id
        ORDER BY ch.id DESC
    ''').fetchall()
    
    # Get quizzes with chapter names and all details
    quiz_set_1 = conn.execute('''
        SELECT q.*, ch.name as chapter
        FROM quizzes q
        JOIN chapters ch ON q.chapter_id = ch.id
        ORDER BY q.date_of_quiz DESC
        LIMIT 5
    ''').fetchall()

    # Get subject-wise top scores
    subject_scores = []
    subject_attempts = []
    
    for subject in subjects:
        # Get top score for each subject
        top_score = conn.execute('''
            SELECT MAX(s.total_scored) as max_score
            FROM scores s
            JOIN quizzes q ON s.quiz_id = q.id
            JOIN chapters ch ON q.chapter_id = ch.id
            WHERE ch.subject_id = ?
        ''', (subject['id'],)).fetchone()
        subject_scores.append(top_score['max_score'] if top_score['max_score'] is not None else 0)

        # Get number of attempts for each subject
        attempts = conn.execute('''
            SELECT COUNT(DISTINCT s.user_id) as attempt_count
            FROM scores s
            JOIN quizzes q ON s.quiz_id = q.id
            JOIN chapters ch ON q.chapter_id = ch.id
            WHERE ch.subject_id = ?
        ''', (subject['id'],)).fetchone()
        subject_attempts.append(attempts['attempt_count'])
    
    conn.close()
    
    return render_template('admin_dashboard.html',
                         subjects=subjects,
                         chapters=chapters,
                         quiz_set_1=quiz_set_1,
                         subject_scores=subject_scores,
                         subject_attempts=subject_attempts)

@app.route('/user/dashboard')
def user_dashboard():
    if not session.get('user_id') or is_admin():
        return redirect(url_for('login'))
    
    conn = get_db()
    # Get all subjects
    subjects = conn.execute('SELECT * FROM subjects').fetchall()
    
    # Get user's quiz scores
    user_scores = conn.execute('''
        SELECT s.*, q.id as quiz_id, ch.name as chapter_name, su.name as subject_name
        FROM scores s
        JOIN quizzes q ON s.quiz_id = q.id
        JOIN chapters ch ON q.chapter_id = ch.id
        JOIN subjects su ON ch.subject_id = su.id
        WHERE s.user_id = ?
        ORDER BY s.time_stamp_of_attempt DESC
    ''', (session['user_id'],)).fetchall()
    
    # Get available quizzes that the user hasn't attempted yet
    available_quizzes = conn.execute('''
        SELECT DISTINCT q.*, ch.name as chapter_name, s.name as subject_name
        FROM quizzes q
        JOIN chapters ch ON q.chapter_id = ch.id
        JOIN subjects s ON ch.subject_id = s.id
        WHERE q.id NOT IN (
            SELECT quiz_id 
            FROM scores 
            WHERE user_id = ?
        )
        AND q.date_of_quiz <= date('now')
        ORDER BY q.date_of_quiz DESC
    ''', (session['user_id'],)).fetchall()
    
    conn.close()
    
    return render_template('user_dashboard.html',
                         subjects=subjects,
                         user_scores=user_scores,
                         available_quizzes=available_quizzes)

@app.route('/admin/subject/add', methods=['POST'])
def add_subject():
    if not is_admin():
        return redirect(url_for('login'))
    
    name = request.form['name']
    description = request.form['description']
    
    conn = get_db()
    conn.execute('INSERT INTO subjects (name, description) VALUES (?, ?)',
                (name, description))
    conn.commit()
    conn.close()
    
    flash('Subject added successfully!')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/chapter/add', methods=['POST'])
def add_chapter():
    if not is_admin():
        return redirect(url_for('login'))
    
    subject_id = request.form['subject_id']
    name = request.form['name']
    description = request.form['description']
    
    conn = get_db()
    conn.execute('INSERT INTO chapters (subject_id, name, description) VALUES (?, ?, ?)',
                (subject_id, name, description))
    conn.commit()
    conn.close()
    
    flash('Chapter added successfully!')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/quiz/create', methods=['GET', 'POST'])
def create_quiz():
    if not is_admin():
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        chapter_id = request.form['chapter_id']
        date_of_quiz = request.form['date_of_quiz']
        time_duration = int(request.form['time_duration'])  # Convert to integer
        remarks = request.form['remarks']
        
        conn = get_db()
        cursor = conn.execute('''
            INSERT INTO quizzes (chapter_id, date_of_quiz, time_duration, remarks)
            VALUES (?, ?, ?, ?)''', (chapter_id, date_of_quiz, time_duration, remarks))
        quiz_id = cursor.lastrowid
        
        questions = request.form.getlist('question[]')
        options_1 = request.form.getlist('option_1[]')
        options_2 = request.form.getlist('option_2[]')
        options_3 = request.form.getlist('option_3[]')
        options_4 = request.form.getlist('option_4[]')
        correct_answers = request.form.getlist('correct_answer[]')
        
        for i in range(len(questions)):
            conn.execute('''
                INSERT INTO questions 
                (quiz_id, question_text, option_1, option_2, option_3, option_4, correct_answer)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (quiz_id, questions[i], options_1[i], options_2[i], options_3[i], options_4[i], correct_answers[i]))
        
        conn.commit()
        conn.close()
        flash('Quiz created successfully!')
        return redirect(url_for('admin_dashboard'))
    
    conn = get_db()
    chapters = conn.execute('''
        SELECT ch.*, s.name as subject_name
        FROM chapters ch
        JOIN subjects s ON ch.subject_id = s.id
    ''').fetchall()
    conn.close()
    
    return render_template('create_quiz.html', chapters=chapters)

@app.route('/quiz/take/<int:quiz_id>', methods=['GET', 'POST'])
def take_quiz(quiz_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    
    conn = get_db()
    
    # Get quiz details
    quiz = conn.execute('''
        SELECT q.*, ch.name as chapter_name, s.name as subject_name
        FROM quizzes q
        JOIN chapters ch ON q.chapter_id = ch.id
        JOIN subjects s ON ch.subject_id = s.id
        WHERE q.id = ? AND q.date_of_quiz <= date('now')
    ''', (quiz_id,)).fetchone()
    
    if not quiz:
        flash('Quiz not found or not available yet!', 'error')
        return redirect(url_for('user_dashboard'))
    
    questions = conn.execute('SELECT * FROM questions WHERE quiz_id = ?', (quiz_id,)).fetchall()
    
    if request.method == 'POST':
        score = 0
        answers = {}
        total_attempted = 0
        for question in questions:
            user_answer = request.form.get(f'question_{question["id"]}')
            if user_answer:
                total_attempted += 1
                if int(user_answer) == question['correct_answer']:
                    score += 1
            answers[question['id']] = int(user_answer) if user_answer else None
        
        # Record the attempt
        conn.execute('''
            INSERT INTO scores (quiz_id, user_id, time_stamp_of_attempt, total_scored)
            VALUES (?, ?, datetime('now'), ?)
        ''', (quiz_id, session['user_id'], score))
        conn.commit()
        
        # Store answers in session for result display
        session['last_quiz_answers'] = answers
        
        percentage = (score/len(questions)) * 100
        flash(f'Quiz completed! Your score: {percentage:.1f}%', 'success')
        return redirect(url_for('quiz_results', quiz_id=quiz_id))
    
    conn.close()
    return render_template('take_quiz.html', quiz=quiz, questions=questions)

@app.route('/quiz/results/<int:quiz_id>')
def quiz_results(quiz_id):
    if not session.get('user_id'):
        return redirect(url_for('login'))
    
    conn = get_db()
    
    # Get quiz details and questions
    quiz = conn.execute('''
        SELECT q.*, ch.name as chapter_name, s.name as subject_name
        FROM quizzes q
        JOIN chapters ch ON q.chapter_id = ch.id
        JOIN subjects s ON ch.subject_id = s.id
        WHERE q.id = ?
    ''', (quiz_id,)).fetchone()
    
    if not quiz:
        flash('Quiz not found!', 'error')
        return redirect(url_for('user_dashboard'))
    
    questions = conn.execute('SELECT * FROM questions WHERE quiz_id = ?', (quiz_id,)).fetchall()
    
    # Get the latest attempt for this quiz
    score = conn.execute('''
        SELECT total_scored
        FROM scores
        WHERE quiz_id = ? AND user_id = ?
        ORDER BY time_stamp_of_attempt DESC
        LIMIT 1
    ''', (quiz_id, session['user_id'])).fetchone()
    
    # Get answers from session
    answers = session.get('last_quiz_answers', {})
    
    # Calculate unanswered questions
    unanswered = sum(1 for q in questions if answers.get(q['id']) is None)
    
    # Calculate wrong answers
    wrong_answers = sum(1 for q in questions if answers.get(q['id']) is not None and answers.get(q['id']) != q['correct_answer'])
    
    conn.close()
    return render_template('quiz_results.html',
                         quiz=quiz,
                         questions=questions,
                         score=score['total_scored'],
                         total_questions=len(questions),
                         answers=answers,
                         unanswered=unanswered,
                         wrong_answers=wrong_answers)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/admin/subject/<int:subject_id>/delete', methods=['POST'])
def delete_subject(subject_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return 'Unauthorized', 401
    
    conn = get_db()
    try:
        # First get all chapters for this subject
        chapters = conn.execute('SELECT id FROM chapters WHERE subject_id = ?', (subject_id,)).fetchall()
        
        # For each chapter, delete associated quizzes and their questions/scores
        for chapter in chapters:
            # Get quizzes for this chapter
            quizzes = conn.execute('SELECT id FROM quizzes WHERE chapter_id = ?', (chapter['id'],)).fetchall()
            
            for quiz in quizzes:
                # Delete questions
                conn.execute('DELETE FROM questions WHERE quiz_id = ?', (quiz['id'],))
                # Delete scores
                conn.execute('DELETE FROM scores WHERE quiz_id = ?', (quiz['id'],))
                # Delete quiz
                conn.execute('DELETE FROM quizzes WHERE id = ?', (quiz['id'],))
        
        # Now delete all chapters
        conn.execute('DELETE FROM chapters WHERE subject_id = ?', (subject_id,))
        # Finally delete the subject
        conn.execute('DELETE FROM subjects WHERE id = ?', (subject_id,))
        conn.commit()
        return 'OK', 200
    except Exception as e:
        conn.rollback()
        return str(e), 500
    finally:
        conn.close()

@app.route('/admin/chapter/<int:chapter_id>/delete', methods=['POST'])
def delete_chapter(chapter_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return 'Unauthorized', 401
    
    conn = get_db()
    try:
        # Get all quizzes for this chapter
        quizzes = conn.execute('SELECT id FROM quizzes WHERE chapter_id = ?', (chapter_id,)).fetchall()
        
        # For each quiz, delete associated questions and scores
        for quiz in quizzes:
            # Delete questions
            conn.execute('DELETE FROM questions WHERE quiz_id = ?', (quiz['id'],))
            # Delete scores
            conn.execute('DELETE FROM scores WHERE quiz_id = ?', (quiz['id'],))
            # Delete quiz
            conn.execute('DELETE FROM quizzes WHERE id = ?', (quiz['id'],))
        
        # Now delete the chapter
        conn.execute('DELETE FROM chapters WHERE id = ?', (chapter_id,))
        conn.commit()
        return 'OK', 200
    except Exception as e:
        conn.rollback()
        return str(e), 500
    finally:
        conn.close()

@app.route('/admin/question/add', methods=['POST'])
def add_question():
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    quiz_id = request.form.get('quiz_id')
    question_text = request.form.get('question_text')
    option_1 = request.form.get('option_1')
    option_2 = request.form.get('option_2')
    option_3 = request.form.get('option_3')
    option_4 = request.form.get('option_4')
    correct_answer = request.form.get('correct_answer')
    
    conn = get_db()
    conn.execute('''
        INSERT INTO questions 
        (quiz_id, question_text, option_1, option_2, option_3, option_4, correct_answer)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (quiz_id, question_text, option_1, option_2, option_3, option_4, correct_answer))
    conn.commit()
    conn.close()
    
    flash('Question added successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/subject/edit', methods=['POST'])
def edit_subject():
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    subject_id = request.form['subject_id']
    name = request.form['name']
    description = request.form['description']
    
    conn = get_db()
    conn.execute('''
        UPDATE subjects 
        SET name = ?, description = ? 
        WHERE id = ?''', (name, description, subject_id))
    conn.commit()
    conn.close()
    
    flash('Subject updated successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/chapter/edit', methods=['POST'])
def edit_chapter():
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    chapter_id = request.form['chapter_id']
    subject_id = request.form['subject_id']
    name = request.form['name']
    description = request.form['description']
    
    conn = get_db()
    conn.execute('''
        UPDATE chapters 
        SET subject_id = ?, name = ?, description = ? 
        WHERE id = ?''', (subject_id, name, description, chapter_id))
    conn.commit()
    conn.close()
    
    flash('Chapter updated successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/quiz/edit', methods=['POST'])
def edit_quiz():
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    quiz_id = request.form['quiz_id']
    time_duration = request.form['time_duration']
    remarks = request.form['remarks']
    
    try:
        conn = get_db()
        # First check if quiz exists
        quiz = conn.execute('SELECT * FROM quizzes WHERE id = ?', (quiz_id,)).fetchone()
        if not quiz:
            flash('Quiz not found!', 'error')
            return redirect(url_for('admin_dashboard'))
            
        conn.execute('''
            UPDATE quizzes 
            SET time_duration = ?, remarks = ?
            WHERE id = ?''', (time_duration, remarks, quiz_id))
        conn.commit()
        conn.close()
        
        flash('Quiz updated successfully!', 'success')
    except Exception as e:
        flash(f'Error updating quiz: {str(e)}', 'error')
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/quiz/<int:quiz_id>/edit')
def edit_quiz_page(quiz_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    quiz = conn.execute('''
        SELECT q.*, ch.name as chapter
        FROM quizzes q
        JOIN chapters ch ON q.chapter_id = ch.id
        WHERE q.id = ?
    ''', (quiz_id,)).fetchone()
    
    if not quiz:
        flash('Quiz not found!', 'error')
        return redirect(url_for('admin_dashboard'))
    
    # Convert quiz Row to dictionary
    quiz_dict = dict(quiz)
    
    # Fetch questions and convert each Row to dictionary
    questions = conn.execute('SELECT * FROM questions WHERE quiz_id = ?', (quiz_id,)).fetchall()
    questions_list = [dict(q) for q in questions]
    
    conn.close()
    
    return render_template('edit_quiz.html', quiz=quiz_dict, questions=questions_list)

@app.route('/admin/quiz/<int:quiz_id>/update', methods=['POST'])
def update_quiz_details(quiz_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    time_duration = request.form['time_duration']
    remarks = request.form['remarks']
    
    try:
        conn = get_db()
        conn.execute('''
            UPDATE quizzes 
            SET time_duration = ?, remarks = ?
            WHERE id = ?
        ''', (time_duration, remarks, quiz_id))
        conn.commit()
        conn.close()
        
        flash('Quiz details saved successfully!', 'success')
    except Exception as e:
        flash(f'Error updating quiz details: {str(e)}', 'error')
    
    return redirect(url_for('edit_quiz_page', quiz_id=quiz_id))

@app.route('/admin/quiz/<int:quiz_id>/question/add', methods=['POST'])
def add_question_to_quiz(quiz_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    question_text = request.form['question_text']
    option_1 = request.form['option_1']
    option_2 = request.form['option_2']
    option_3 = request.form['option_3']
    option_4 = request.form['option_4']
    correct_answer = request.form['correct_answer']
    
    conn = get_db()
    conn.execute('''
        INSERT INTO questions 
        (quiz_id, question_text, option_1, option_2, option_3, option_4, correct_answer)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (quiz_id, question_text, option_1, option_2, option_3, option_4, correct_answer))
    conn.commit()
    conn.close()
    
    flash('Question added successfully!', 'success')
    return redirect(url_for('edit_quiz_page', quiz_id=quiz_id))

@app.route('/admin/question/<int:question_id>/edit', methods=['POST'])
def edit_question(question_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    question_text = request.form['question_text']
    option_1 = request.form['option_1']
    option_2 = request.form['option_2']
    option_3 = request.form['option_3']
    option_4 = request.form['option_4']
    correct_answer = request.form['correct_answer']
    
    conn = get_db()
    try:
        # Get the quiz_id first
        quiz = conn.execute('SELECT quiz_id FROM questions WHERE id = ?', (question_id,)).fetchone()
        if not quiz:
            flash('Question not found!', 'error')
            return redirect(url_for('admin_dashboard'))
            
        quiz_id = quiz['quiz_id']
        
        # Update the question
        conn.execute('''
            UPDATE questions 
            SET question_text = ?, option_1 = ?, option_2 = ?, option_3 = ?, option_4 = ?, correct_answer = ?
            WHERE id = ?
        ''', (question_text, option_1, option_2, option_3, option_4, correct_answer, question_id))
        conn.commit()
        
        flash('Question updated successfully!', 'success')
        return redirect(url_for('edit_quiz_page', quiz_id=quiz_id))
    
    except Exception as e:
        flash(f'Error updating question: {str(e)}', 'error')
        return redirect(url_for('admin_dashboard'))
    finally:
        conn.close()

@app.route('/admin/question/<int:question_id>/delete', methods=['POST'])
def delete_question(question_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return 'Unauthorized', 401
    
    conn = get_db()
    conn.execute('DELETE FROM questions WHERE id = ?', (question_id,))
    conn.commit()
    conn.close()
    
    return 'OK', 200

@app.route('/admin/quiz/<int:quiz_id>/delete', methods=['POST'])
def delete_quiz(quiz_id):
    if not session.get('user_id') or session.get('role') != 'admin':
        return 'Unauthorized', 401
    
    conn = get_db()
    try:
        # Delete associated questions first
        conn.execute('DELETE FROM questions WHERE quiz_id = ?', (quiz_id,))
        # Delete associated scores
        conn.execute('DELETE FROM scores WHERE quiz_id = ?', (quiz_id,))
        # Delete the quiz
        conn.execute('DELETE FROM quizzes WHERE id = ?', (quiz_id,))
        conn.commit()
        return 'OK', 200
    except Exception as e:
        return str(e), 500
    finally:
        conn.close()

@app.before_request
def make_session_permanent():
    session.permanent = True
    if 'user_id' in session:
        session.modified = True  # Refresh session on each request

if __name__ == '__main__':
    app.run(debug=True)